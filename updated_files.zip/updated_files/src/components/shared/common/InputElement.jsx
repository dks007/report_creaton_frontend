import React from 'react'

const InputElement = ({ ...props }) => {
  return <input {...props} />
}

export default InputElement

export const routePath = {
  DASHBOARD: '/dashboard',
  LOGIN: '/',
  HOME: '/',
  ISSUE_LISTING: '/issue-listing',
  ISSUEBYID: '/issue-details/'
}
